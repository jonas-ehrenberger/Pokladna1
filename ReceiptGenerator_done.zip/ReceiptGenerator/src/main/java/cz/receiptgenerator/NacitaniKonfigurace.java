package cz.receiptgenerator;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Načte údaje obchodu ze souboru nebo z resources JARu. */
public class NacitaniKonfigurace {
    public static Obchod nactiZSouboru(String nazevSouboru) {
        Properties properties = new Properties();
        try (InputStream input = Files.isRegularFile(Path.of(nazevSouboru))
                ? Files.newInputStream(Path.of(nazevSouboru))
                : NacitaniKonfigurace.class.getClassLoader().getResourceAsStream(nazevSouboru)) {
            if (input == null) throw new IOException("Soubor nebyl nalezen");
            properties.load(input);
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("Konfiguraci '" + nazevSouboru + "' nelze načíst; použijí se výchozí údaje.");
            return new Obchod("Neznámý obchod", "Neznámá adresa", "00000000", "Děkujeme za nákup!");
        }
        return new Obchod(properties.getProperty("nazev", "Standardní obchod"),
                properties.getProperty("adresa", "Neznámá adresa"),
                properties.getProperty("ico", "00000000"),
                properties.getProperty("podekovani", "Děkujeme za nákup!"));
    }
}

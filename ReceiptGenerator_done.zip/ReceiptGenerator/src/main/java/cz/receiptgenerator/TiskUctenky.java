package cz.receiptgenerator;

import java.util.Locale;

/** Vytváří jednoduchou textovou účtenku. */
public class TiskUctenky {
    public String vytvorUctenku(Obchod obchod, Nakup nakup) {
        if (obchod == null || nakup == null) throw new IllegalArgumentException("Obchod ani nákup nesmí být null.");
        StringBuilder uctenka = new StringBuilder();
        uctenka.append("============================\n");
        uctenka.append(obchod.getNazev()).append("\n");
        uctenka.append(obchod.getAdresa()).append("\n");
        uctenka.append("ICO: ").append(obchod.getIco()).append("\n");
        uctenka.append("============================\n");
        for (Produkt produkt : nakup.getProdukty()) {
            uctenka.append(produkt.getNazev()).append(" | ")
                    .append(produkt.getPocetKusu()).append(" x ")
                    .append(cena(produkt.getCena())).append(" Kč = ")
                    .append(cena(produkt.getCelkovaCenaPolozky())).append(" Kč\n");
        }
        uctenka.append("----------------------------\n");
        uctenka.append("CELKEM: ").append(cena(nakup.getCelkovaCena())).append(" Kč\n");
        uctenka.append("============================\n");
        uctenka.append(obchod.getPodekovani()).append("\n");
        uctenka.append("============================\n");
        return uctenka.toString();
    }

    private String cena(double castka) {
        return String.format(Locale.ROOT, "%.2f", castka);
    }
}

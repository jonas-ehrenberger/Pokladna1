package cz.receiptgenerator;

import java.util.Scanner;

/** Vstupní bod aplikace. */
public class Main {
    public static void main(String[] args) {
        System.out.println("ReceiptGenerator v1.0.0");
        String konfigurace = args.length > 0 ? args[0] : "obchod.properties";
        Obchod obchod = NacitaniKonfigurace.nactiZSouboru(konfigurace);
        try (Scanner scanner = new Scanner(System.in)) {
            Nakup nakup = new Konzole().nactiNakup(scanner);
            System.out.println();
            System.out.print(new TiskUctenky().vytvorUctenku(obchod, nakup));
        } catch (IllegalStateException e) {
            System.err.println("Nákup nelze dokončit: " + e.getMessage());
            System.exit(1);
        }
    }
}

package cz.receiptgenerator;

import java.util.Scanner;

/** Načte nákup z konzole; Scanner zůstává ve správě volajícího. */
public class Konzole {
    public Nakup nactiNakup(Scanner scanner) {
        Nakup nakup = new Nakup();
        System.out.println("Zadávání produktů (pro ukončení napište konec).");
        while (true) {
            System.out.print("Název produktu: ");
            if (!scanner.hasNextLine()) break;
            String nazev = scanner.nextLine().trim();
            if (nazev.equalsIgnoreCase("konec")) break;
            if (nazev.isEmpty()) {
                System.out.println("Název nesmí být prázdný.");
                continue;
            }
            double cena = nactiCenu(scanner);
            int pocet = nactiPocet(scanner);
            nakup.pridatProdukt(new Produkt(nazev, cena, pocet));
            System.out.println("Položka přidána.");
        }
        return nakup;
    }

    private double nactiCenu(Scanner scanner) {
        while (true) {
            System.out.print("Cena za kus (Kč): ");
            if (!scanner.hasNextLine()) throw new IllegalStateException("Vstup skončil při zadávání ceny.");
            String vstup = scanner.nextLine().trim().replace(',', '.');
            try {
                double cena = Double.parseDouble(vstup);
                if (Double.isFinite(cena) && cena >= 0 && Math.round(cena * 100.0) / 100.0 == cena) return cena;
            } catch (NumberFormatException ignored) { }
            System.out.println("Zadejte platnou nezápornou cenu, maximálně na dvě desetinná místa.");
        }
    }

    private int nactiPocet(Scanner scanner) {
        while (true) {
            System.out.print("Počet kusů: ");
            if (!scanner.hasNextLine()) throw new IllegalStateException("Vstup skončil při zadávání počtu.");
            try {
                int pocet = Integer.parseInt(scanner.nextLine().trim());
                if (pocet > 0) return pocet;
            } catch (NumberFormatException ignored) { }
            System.out.println("Zadejte kladné celé číslo.");
        }
    }
}

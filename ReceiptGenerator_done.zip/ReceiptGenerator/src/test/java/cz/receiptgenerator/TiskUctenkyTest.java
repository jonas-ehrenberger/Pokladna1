package cz.receiptgenerator;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TiskUctenkyTest {
    @Test void obsahujeUdajePolozkyASoucet() {
        Nakup nakup = new Nakup();
        nakup.pridatProdukt(new Produkt("Rohlík", 3.50, 5));
        String text = new TiskUctenky().vytvorUctenku(
                new Obchod("Mini market", "Praha", "12345678", "Děkujeme!"), nakup);
        assertTrue(text.contains("Mini market"));
        assertTrue(text.contains("Rohlík | 5 x 3.50 Kč = 17.50 Kč"));
        assertTrue(text.contains("CELKEM: 17.50 Kč"));
        assertTrue(text.contains("Děkujeme!"));
    }
    @Test void prazdnyNakupMaNulovouCenu() {
        String text = new TiskUctenky().vytvorUctenku(
                new Obchod("Obchod", "Praha", "123", "Díky"), new Nakup());
        assertTrue(text.contains("CELKEM: 0.00 Kč"));
    }
}

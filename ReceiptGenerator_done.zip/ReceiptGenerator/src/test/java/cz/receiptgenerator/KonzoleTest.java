package cz.receiptgenerator;

import org.junit.jupiter.api.Test;
import java.util.Scanner;
import static org.junit.jupiter.api.Assertions.*;

class KonzoleTest {
    @Test void nacteDvePolozky() {
        Nakup nakup = new Konzole().nactiNakup(new Scanner("Rohlík\n3,50\n5\nMléko\n29.90\n2\nkonec\n"));
        assertEquals(2, nakup.getProdukty().size());
        assertEquals(77.30, nakup.getCelkovaCena(), 0.001);
    }
    @Test void opravujeNeplatneVstupy() {
        Nakup nakup = new Konzole().nactiNakup(new Scanner("\nChléb\n-1\nabc\n20\n0\nxyz\n2\nkonec\n"));
        assertEquals(40, nakup.getCelkovaCena(), 0.001);
    }
    @Test void konecBezPolozek() {
        assertTrue(new Konzole().nactiNakup(new Scanner("konec\n")).jePrazdny());
    }
}

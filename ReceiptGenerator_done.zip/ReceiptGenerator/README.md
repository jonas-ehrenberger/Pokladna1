# ReceiptGenerator

**Version:** 1.0.0  
**Language:** Java 17  
**Build tool:** Apache Maven

ReceiptGenerator is a simple command-line application that generates a store-style receipt. It loads store information from a properties file, accepts purchased products from the user, calculates the total price, and prints a receipt in the terminal.

## Team members

| Team member | Name | Main responsibilities |
| --- | --- | --- |
| 1 | **Jonas Ehrenberger** | Product and purchase classes, calculations, unit tests |
| 2 | **František Včelička** | Store information and configuration loading, unit tests |
| 3 | **Kevin Nguyen** | Receipt formatting and printing, unit tests |
| 4 | **Ondřej Korecký** | Console input, application entry point, Maven setup, documentation and integration |

## Requirements

- **Java 17 or newer** to run the application.
- **Maven 3.9+** and a JDK to build the application from source.
- IntelliJ IDEA is optional; the program can run without an IDE.

## How to run the application

### Option A: Run the prebuilt JAR

Open a terminal in the folder containing `receipt-generator-1.0.0.jar` and run:

```bash
java -jar receipt-generator-1.0.0.jar
```

### Option B: Build from source with Maven

Open a terminal in the project root directory (the folder containing `pom.xml`) and execute:

```bash
mvn clean package
java -jar target/receipt-generator-1.0.0.jar
```

The `package` command compiles the code, runs the automated tests, and creates the JAR file in `target/`. A failed test prevents a normal Maven build from completing.

## How to use the program

1. Start the application with one of the commands above.
2. Enter a **product name** (e.g., `Bread`).
3. Enter its **unit price** (e.g., `25.90`). Both a period and a comma are accepted as the decimal separator.
4. Enter the **quantity** as a positive whole number (e.g., `2`).
5. Repeat for any additional products.
6. Enter **`konec`** when asked for a product name to finish the purchase.
7. The program prints a receipt with store details, products, quantities, prices and the total.

Invalid prices and quantities are rejected and you will be asked to enter them again. The current version uses Czech console prompts and prices in CZK.

### Example input

```text
Product name: Bread
Unit price: 25.90
Quantity: 2
Product name: Milk
Unit price: 29.90
Quantity: 1
Product name: konec
```

The purchase total in this example is **81.70 CZK**. The actual prompts appear in Czech.

## Store configuration

The default store information is defined in:

```text
src/main/resources/obchod.properties
```

The configuration file contains the following keys:

```properties
nazev=Potraviny U Ondry
adresa=Praha, Česká republika
ico=12345678
podekovani=Děkujeme za nákup!
```

To change the default store information, edit this file and rebuild the project. You can also pass an external properties file as the first command-line argument:

```bash
java -jar target/receipt-generator-1.0.0.jar path/to/obchod.properties
```

If an external configuration file cannot be read, the application falls back to the bundled/default store details.

## Automated tests

Run all unit tests from the project root:

```bash
mvn clean test
```

Tests cover the main purchase, product, configuration, input and receipt functionality.

## How to release a new version

1. Make changes in a feature branch and submit a pull request for review.
2. Update the `<version>` value in `pom.xml` and the version displayed in `Main.java` and this README.
3. Run `mvn clean test` to check the automated tests.
4. Run `mvn clean package` to build the new JAR.
5. Test the JAR with `java -jar target/receipt-generator-NEW_VERSION.jar` (replace `NEW_VERSION` with the updated version).
6. Commit and push the changes, merge them into `main`, and optionally create a Git tag (for example, `v1.0.1`).

## Project structure

```text
ReceiptGenerator/
├── pom.xml
├── README.md
└── src/
    ├── main/
    │   ├── java/cz/receiptgenerator/
    │   └── resources/obchod.properties
    └── test/java/cz/receiptgenerator/
```

## Collaboration

All four team members contribute through GitHub. Their contributions can be reviewed in the repository's commit history and pull requests.
